# Short-Term TO-DO

+ **LAB01+2 VIGNETTES READY TO GO**
+ Stlye files

# Data

+ Algebra check the order of citation. Found in 36-202 Spring 2016 lab 6
+ Calculators: Email Weinberg
+ Confirm COLVARD reference
+ Countries

# Summer 202

## Vignettes

+ Vignette functionality
+ Documentation
+ **Fix help bug**

## Course

+ Lab 01 sheet for how to log-in and change password and whatnot
+ Walk-through what are you looking at? Write out the lab
+ Go through lab01 and lab02 and what is a vignette and what is not
+ Load in lab01 and lab02
+ Write Frank demonstration for lab01 --> *what is R*?

