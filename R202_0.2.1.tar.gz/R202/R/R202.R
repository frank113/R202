#' @keywords internal
#' @importFrom "utils" "vignette"
"_PACKAGE"
