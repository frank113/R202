#' @keywords internal
#' @importFrom "utils" "vignette"
#' @importFrom "stats" "IQR"
#' @importFrom "stats" "quantile"
#' @importFrom "stats" "median"
"_PACKAGE"
