## ----setup, include = FALSE----------------------------------------------
library(cmu202)

knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.align = "center",
  warning = FALSE,
  message = FALSE,
  echo = FALSE,
  fig.width = 7,
  height = 6
)

## ---- echo=FALSE, eval=TRUE, comment = ""--------------------------------
cat(htmltools::includeText("code_chunk_example.txt"))

## ---- echo=FALSE, eval=TRUE, comment = ""--------------------------------
cat(htmltools::includeText("code_chunk_echo.txt"))

