## ----setup, include = FALSE----------------------------------------------
## library(R202)
## library(ggplot2)

## load("../R/sysdata.rda")
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.align = "center",
  warning = FALSE,
  message = FALSE,
  echo = FALSE,
  fig.width = 7,
  height = 6
)

axis.size <- 20
font <- "Times"


