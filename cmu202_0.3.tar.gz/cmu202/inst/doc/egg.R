## ----setup, include = FALSE----------------------------------------------
library(cmu202)
library(ggplot2)
library(dplyr)
library(readr)

pokemon <- readr::read_csv("egg_files/pokemon.csv")
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.align = "center",
  warning = FALSE,
  message = FALSE,
  echo = FALSE,
  fig.width = 7,
  height = 6
)

axis.size <- 20
font <- "Times"

vignette.theme <- theme(rect = element_rect(fill = "white", 
                                            colour = "black", size = 0.5), 
                        text = element_text(face = "plain", colour = "black", 
                                            size = 11, hjust = 0.5, 
                                            vjust = 0.5, angle = 0, 
                                            lineheight = 0), 
                        axis.title.x = element_text(size = axis.size, vjust = 1, 
                                             family = font), 
                        axis.title.y = element_text(size = axis.size, angle = 90, 
                                                    vjust = 1), 
                        axis.text.x = element_text(size = 15, vjust = 1), 
                        axis.text.y = element_text(size = 15, hjust = 1), 
                        axis.ticks = element_line(size = 0, colour = "grey20"), 
                        plot.title = element_text(family = font, face = "bold", 
                                                  size = 25, hjust = 0.5, 
                                                  vjust = 1))

## ----transform capture rate, echo=TRUE-----------------------------------
# Handle Minior meteor captur rate
minior.index <- which(pokemon$capture_rate == "30 (Meteorite)255 (Core)")
pokemon$capture_rate[[minior.index]] = "30"

# Make strings into number
pokemon$capture_rate <- as.numeric(pokemon$capture_rate)

## ------------------------------------------------------------------------
plot.capture <- ggplot(data = pokemon, 
                       aes(x = capture_rate)) + 
  geom_histogram(alpha=0.86,
           size=1,
           bins = 31) + 
  xlab("Capture Rate") + 
  ylab("Count") + 
  ggtitle("Distribution of Capture Rate") + 
  vignette.theme
plot.capture

## ----eval=FALSE, echo=TRUE-----------------------------------------------
#  plot.capture <- ggplot(data = pokemon,
#                         aes(x = capture_rate)) +
#    geom_histogram(alpha=0.86,
#             size=1,
#             bins = 31) +
#    xlab("Capture Rate") +
#    ylab("Count") +
#    ggtitle("Distribution of Capture Rate") +
#    vignette.theme
#  plot.capture

