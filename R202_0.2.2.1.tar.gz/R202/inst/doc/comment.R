## ----setup, include = FALSE----------------------------------------------
library(R202)

knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.align = "center",
  warning = FALSE,
  message = FALSE,
  echo = FALSE,
  fig.width = 7,
  height = 6
)

## ---- echo=TRUE, eval=FALSE----------------------------------------------
#  library(R202)
#  cat("This is text")
#  # Load the library and print some text
#  
#  y <- 1356
#  
#  ### Comments can have multiple #s starting the lines
#  
#  x <- 5 # A comment with code

