## ----setup, include = FALSE----------------------------------------------
library(R202)

knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.align = "center",
  warning = FALSE,
  message = FALSE,
  echo = FALSE,
  fig.width = 7,
  height = 6
)

## ---- echo=TRUE, eval=FALSE----------------------------------------------
#  # This example is incredibly bad style, as you would always install a package in the terminal
#  
#  install.packages("ggplot2")

## ----echo=TRUE, eval=FALSE-----------------------------------------------
#  library(ggplot2)

