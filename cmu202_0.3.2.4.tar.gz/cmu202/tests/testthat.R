library(testthat)
library(cmu202)

test_check("cmu202")

