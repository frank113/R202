## ----setup, include = FALSE----------------------------------------------
library(cmu202)
library(ggplot2)

knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.align = "center",
  warning = FALSE,
  message = FALSE,
  echo = TRUE,
  eval=FALSE,
  fig.width = 7,
  height = 6
)

## ---- echo=TRUE, eval=FALSE----------------------------------------------
#  View(data_name)

## ---- eval=TRUE----------------------------------------------------------
# Load the data for the example
library(cmu202)
data("airlines")

head(airlines)

## ---- eval=TRUE----------------------------------------------------------
# Load the data for the example
library(cmu202)
data("airlines")

tail(airlines)

